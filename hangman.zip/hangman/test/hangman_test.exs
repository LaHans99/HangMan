defmodule HangmanTest do
  use ExUnit.Case

  test "greets the world" do
    assert Hangman.hello() == :world
  end
end
